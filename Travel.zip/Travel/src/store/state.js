let defaultCity = '上海'
try {//防止用户禁用本地存储功能
    if (localStorage.city) {
        defaultCity = localStorage.city
    }
} catch (error) {
    
}

export default {
    city: defaultCity
}