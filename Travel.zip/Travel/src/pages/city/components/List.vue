<template>
    <div class="list" ref="wrapper">
        <div>
            <div class="area">
                <div class="title border-topbottom">当前城市</div>
                <div class="button-list">
                    <div class="button-wrapper">
                        <div class="button">{{ this.currentCity }}</div>
                    </div>
                </div>
            </div>
            <div class="area">
                <div class="title border-topbottom">热门城市</div>
                <div class="button-list">
                    <div class="button-wrapper" @click="handleCityClick(item.name)" v-for="item in hot" :key="item.id">
                        <div class="button">{{ item.name }}</div>
                    </div>
                </div>
            </div>
            <div class="area" v-for="(item, key) in cities" :key="key" :ref="key">
                <div class="title border-topbottom ">{{ key }}</div>
                <div class="item-list">
                    <div class="item border-bottom" @click="handleCityClick(innerItem.name)" v-for="innerItem in item"  :key="innerItem.id">{{ innerItem.name }}</div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import BScroll from 'better-scroll'
import { mapState, mapMutations } from 'vuex' 
export default {
    name: 'CityList',
    props: {
        cities: Object,
        hot: Array,
        letter: String
    },
    computed: {
        ...mapState({
            currentCity: 'city'
        })
    },
    methods: {
        handleCityClick (city) {
            // alert(city)
            // this.$store.commit('changeCity', city)
            this.changeCity(city)
            this.$router.push('/')// 编程式页面跳转
        },
        ...mapMutations(['changeCity'])
    },
    mounted() {
        this.scroll = new BScroll(this.$refs.wrapper)
    },
    watch: {
        letter() {
            // console.log(this.letter)
            if (this.letter) {
                const element = this.$refs[this.letter][0]
                this.scroll.scrollToElement(element)//插件带的方法
            }
        }
    }
}
</script>
<style lang="stylus" scoped>
    .border-topbottom
        &:before
            border-color #ccc
        &:after
            border-color #ccc
    .border-bottom
        &:before
            border-color #ccc
    .list
        position absolute
        overflow hidden
        top 1.58rem
        left 0
        right 0
        bottom 0 
        .title
            line-height .54rem
            background #eeeeee
            padding-left .2rem
            color #666
            font-size .26rem
        .button-list
            padding .1rem .6rem .1rem .1rem
            overflow hidden 
            .button-wrapper
                width 33.33%
                float left
                .button
                    text-align center
                    margin .1rem   
                    padding .1rem 0
                    border-radius .06rem
                    border .02rem solid #ccc
        .item-list
            .item
                line-height .76rem
                padding-left .2rem
</style>
