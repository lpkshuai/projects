<template>
    <div>
        <home-header></home-header>
        <home-swiper :list="swiperList"></home-swiper>
        <home-icons :list="iconList"></home-icons>
        <home-recommend :list="recommendList"></home-recommend>
        <home-weekend :list="weekendList"></home-weekend>
    </div>
</template>
<script>
import HomeHeader from './components/Header';//引入头部子组件
import HomeSwiper from './components/Swiper';//引入轮播子组件
import HomeIcons from './components/Icons';//引入轮播子组件
import HomeRecommend from './components/Recommend';//引入热门榜单子组件
import HomeWeekend from './components/Weekend';//引入热门榜单子组件
import axios from 'axios';
import { mapState } from 'vuex'
export default {
    data() {
        return {
            lastCity: '',
            swiperList: [],
            iconList: [],
            recommendList: [],
            weekendList: []
        }
    },
    name: 'Home',
    computed: {
        ...mapState(['city'])
    },
    components: {
        HomeHeader,
        HomeSwiper,
        HomeIcons,
        HomeRecommend,
        HomeWeekend
    },
    methods: {
        getHomeInfo() {
            axios.get('/api/index.json?city=' + this.city)
                .then(this.getHomeInfoSucc)
        },
        getHomeInfoSucc(res) {
            // console.log(res)
            res = res.data
            if (res.ret && res.data) {
                const data = res.data
                this.swiperList = data.swiperList
                this.iconList = data.iconList
                this.recommendList = data.recommendList
                this.weekendList = data.weekendList
            }
        }
    },
    mounted() {
        this.lastCity = this.city
        this.getHomeInfo()
    },
    activated() {
        if (this.lastCity !== this.city) {
            this.lastCity = this.city 
            this.getHomeInfo()//重新发Ajax请求 
        }
    }
}
</script>
<style lang="">
    
</style>