<template>
    <div class="icons">
        <swiper>
            <swiper-slide :options="swiperOption" v-for="(page, index) in pages" :key="index"> 
                <div class="icon" v-for="item in page" :key="item.id">
                    <div class="icon-img">
                        <img class="icon-img-content" :src="item.imgUrl" alt="">
                    </div>
                    <p class="icon-desc">{{ item.desc }}</p>
                </div>
            </swiper-slide>
        </swiper>
    </div>
</template>
<script>
export default {
    name: 'HomeIcons',
    props: {
        list: Array
    },
    data() {
        return {
            swiperOption: {
                autoplay: false
			},
            // iconList: [
            //     {id:1, imgUrl:'../../../../static/imgs/icon1.png', desc:'热门景点'},
            //     {id:2, imgUrl:'../../../../static/imgs/icon2.png', desc:'郊游踏青'},
            //     {id:3, imgUrl:'../../../../static/imgs/icon3.png', desc:'室外活动'},
            //     {id:4, imgUrl:'../../../../static/imgs/icon4.png', desc:'外地旅游'},
            //     {id:5, imgUrl:'../../../../static/imgs/icon5.png', desc:'室内活动'},
            //     {id:6, imgUrl:'../../../../static/imgs/icon6.png', desc:'出门带娃'},
            //     {id:7, imgUrl:'../../../../static/imgs/icon7.png', desc:'水上乐园'},
            //     {id:8, imgUrl:'../../../../static/imgs/icon8.png', desc:'迪士尼'},
            //     {id:9, imgUrl:'../../../../static/imgs/icon9.png', desc:'沙滩度假'}
            // ]
        }
    },
    computed: {
        pages() {
            const pages = []
            this.list.forEach((item, index) => {
                const page = Math.floor(index / 8)
                if(!pages[page]) {
                    pages[page] = []
                }
                pages[page].push(item)
            });
            return pages
        }
    }
}
</script>
<style lang="stylus" scoped>
    @import '~styles/varibles.styl';
    @import '~styles/mixins.styl';
    .icons >>> .swiper-container
        height 0
        padding-bottom 50%
    .icons
        margin-top .1rem
        .icon
            position relative
            width 25%
            height 0
            float left
            padding-bottom 25%
            overflow hidden
            .icon-img
                position absolute
                top 0
                left 0
                right 0
                bottom .44rem
                box-sizing border-box
                padding .1rem
                .icon-img-content
                    height 100%
                    display block
                    margin 0 auto
            .icon-desc
                position absolute
                bottom 0
                left 0
                right 0
                height .44rem
                line-height .44rem
                color $darkTextColor
                text-align center
                ellipsis()
</style>