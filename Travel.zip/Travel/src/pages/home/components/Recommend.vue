<template>
    <div>
        <div class="recommend-title">热门榜单</div>
        <ul>
            <router-link tag="li" :to="'/detail/' + item.id" class="item border-bottom" v-for="item in list /*recommendList*/" :key="item.id">
                <img class="item-img" :src="item.imgUrl" alt="">
                <div class="item-info">
                    <p class="item-title">{{ item.title }}</p>
                    <p class="item-desc">{{ item.desc }}</p>
                    <button class="item-btn">查看详情</button>
                </div>
            </router-link>
        </ul>
    </div>
</template>
<script>
export default {
    name: 'HomeRecommend',
    props: {
        list: Array
    },
    data() {
        return {
            // recommendList: [
            //     {id:1, imgUrl:'../../../../static/imgs/tj1.jpg', title:'天涯海角', desc:'将壮观诠释到完美，将梦想展示给世界。'},
            //     {id:2, imgUrl:'../../../../static/imgs/tj2.jpg', title:'蜈支洲岛', desc:'将壮观诠释到完美，将梦想展示给世界。'},
            //     {id:3, imgUrl:'../../../../static/imgs/tj3.jpg', title:'亚龙湾热带天堂森林公园', desc:'将壮观诠释到完美，将梦想展示给世界。'},
            //     {id:4, imgUrl:'../../../../static/imgs/tj4.jpg', title:'珠江南田温泉', desc:'将壮观诠释到完美，将梦想展示给世界。'},
            //     {id:5, imgUrl:'../../../../static/imgs/tj5.jpg', title:'亚特兰蒂斯C秀', desc:'将壮观诠释到完美，将梦想展示给世界。'}
            // ]
        }
    }
}
</script>
<style lang="stylus" scoped>
    @import '~styles/mixins.styl';
    .recommend-title
        line-height 1rem
        background #eee
        text-indent .2rem//第一行缩进
        margin-top .2rem
        font-size .32rem
    .item
        display flex
        height 2rem
        overflow hidden
        padding .2rem
        .item-img
            width 2rem
            height 2rem
        .item-info
            flex 1
            padding .15rem
            min-width 0
            .item-title
                line-height .54rem
                font-size .3rem
                margin-bottom .1rem
                ellipsis()
            .item-desc
                color #aaa
                line-height .4rem
                ellipsis()
            .item-btn
                margin-top .2rem
                background #ff9300
                padding 0 .1rem
                border-radius .06rem
                color #fff
</style>
