<template>
	<div class="wrapper">
		<swiper :options="swiperOption" v-if="showSwiper">
			<!-- slides -->
			<swiper-slide v-for="item in list /*swiperList*/" :key="item.id">
				<img class="swiper-img" :src="item.imgUrl" alt="">
			</swiper-slide>
			<!-- Optional controls -->
			<div class="swiper-pagination" slot="pagination"></div>
		</swiper>
	</div>
</template>
<script>
export default {
	  name: "HomeSwiper",
	  props: {
		list: Array
	  },
	  data() {
			return {
				swiperOption: {
					pagination: '.swiper-pagination',
					loop: true,
					autoplay: 2000
				},
				// swiperList: [
				// 	{id: 1, imgUrl: '../../../../static/imgs/lb1.jpg'},
				// 	{id: 2, imgUrl: '../../../../static/imgs/lb2.jpg'},
				// 	{id: 3, imgUrl: '../../../../static/imgs/lb3.jpg'}
				// ]
			}
	  },
	  computed: {
		  //解决由于开始list空时导致显示图片顺序错误问题
		  showSwiper() {
			  return this.list.length
		  }
	  }
};
</script>
<style lang="stylus" scoped>
	.wrapper >>> .swiper-pagination-bullet-active
		background #fff
	.wrapper
		width 100%
		height 0
		overflow hidden
		padding-bottom 30%  // 保持宽高比
		// height 27vw
		background #eee
		.swiper-img
			width 100%
</style>