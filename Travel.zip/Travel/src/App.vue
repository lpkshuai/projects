<template>
    <div id="app">
        <keep-alive exclude="Detail"><!-- 解决切换路由数据重新加载问题 --><!-- 不让detail缓存 -->
            <router-view/>
        </keep-alive>
    </div>
</template>

<script>
export default {
  name: "App"
};
</script>

<style>
</style>
