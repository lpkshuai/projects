// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import fastclick from 'fastclick';//解决移动端点击事件延迟300毫秒问题
import VueAwesomeSwiper from 'vue-awesome-swiper'//注意此处的版本，新版本有bug不要用
import store from './store'
import 'babel-polyfill'
//引入初始化样式文件（解决不同浏览器初始样式问题）
import 'styles/reset.css';
//引入1px像素边框解决样式文件（手机问题有时导致边框不是一个像素）
import 'styles/border.css';
//引入图标 
import 'styles/iconfont.css';

import 'swiper/dist/css/swiper.css'

Vue.config.productionTip = false

fastclick.attach(document.body);
Vue.use(VueAwesomeSwiper)

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>'
})
