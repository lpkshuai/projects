<?php 

// echo '<pre>';
// print_r($_FILES);
//上传图片
if ($_FILES['file_image']['error']>0) {//上传错误
	exit(json_encode(array('errno'=>1, 'data'=>[])));//errno为0则为正确，详情看编辑器文档
}
//限制上传文件大小和类型(此处采用扩展名判断的方法，实际会有问题出现。如果文件被修改过扩展名就会伪装通过判断)

$allows = array('image/jpg', 'image/png', 'image/jpeg');
if (!in_array($_FILES['file_image']['type'], $allows)) {
	exit(json_encode(array('errno'=>1, 'data'=>[])));
}

//限制上传文件大小和类型
/*
$fi = new finfo(FIELINFO_MIME_TYPE);
$mime_type = $fi->file($_FILES['file_image']['tmp_name']);
// echo $mime_type;
// exit;
$allows = array('image/jpg', 'image/png', 'image/jpeg');
if (!in_array($mime_type, $allows)) {
	exit(json_encode(array('errno'=>1, 'data'=>[])));
}
*/

move_uploaded_file($_FILES['file_image']['tmp_name'], $_SERVER['DOCUMENT_ROOT'].'/images/'.$_FILES['file_image']['name']);

exit(json_encode(array('errno'=>0, 'data'=>['/images/'.$_FILES['file_image']['name']])));