<?php
/**
 * 数据库访问类
 */
class Db{
	private $where = array();
	private $field = '*';
	private $order = '';
	private $limit = 0;
	private $pdo = null;

	public function __construct(){
		//构造函数在实例化类的时候会执行
		$this->pdo = new PDO('mysql:host=127.0.0.1;dbname=myblog', 'root', 'lpk19961224');
		$this->pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
	}
	//指定表名
	public function table($table){
		// echo "article";
		$this->table = $table;
		// $this->where = array();
		return $this;//作用是让链式调用后面的方法能够调用
	}
	//制定查询字段
	public function field($field){
		$this->field = $field;
		return $this;
	}
	//指定排序条件
	public function order($order){
		$this->order = $order;
		return $this;
	}
	//指定查询数量
	public function limit($limit){
		$this->limit = $limit;
		return $this;
	}
	//指定where条件
	public function where($where){
		$this->where = $where;
		return $this;
	}
	//组装where条件
	private function _build_where(){
		$where = '';
		if (is_array($this->where)) {
			//数组方式
			foreach ($this->where as $key => $value) {
				//value是字符串情况要加引号
				$value = is_string($value) ? "'".$value."'" : $value;
				$where .= "`{$key}`={$value} and";
			}
		}else {
			//字符串方式
			$where = $this->where;
		}
		$where = rtrim($where, 'and');
		$where = $where == '' ? '' : "where {$where}";
		return $where;
	}
	//构造sql语句
	private function _build_sql($type, $data = null){
		if ($type == 'select') {
			$where = $this->_build_where();
			$sql = "select {$this->field} from {$this->table} {$where}";
			if ($this->order) {
				$sql .= " order by {$this->order}";
			}
			if ($this->limit) {
				$sql .= " limit {$this->limit}";
			}
		}
		if ($type == 'insert') {
			$sql = "insert into {$this->table}";
			$fields = $values = [];
			foreach ($data as $key => $val) {
				$fields[] = "`".$key."`";
				$values[] = is_string($val) ? "'".$val."'" : $val;
			}
			$sql .= "(".implode(',', $fields).")values(".implode(',', $values).")";
		}
		if ($type == 'delete') {
			$where = $this->_build_where();
			$sql = "delete from {$this->table} {$where}";
		}
		if ($type == 'update') {
			$where = $this->_build_where();
			$str = '';
			foreach ($data as $key => $val) {
				$val = is_string($val) ? "'".$val."'" : $val;
				$str .= "{$key}={$val},";
			}
			$str = rtrim($str, ',');
			$str = $str ? " set {$str}" : '';
			$sql = "update {$this->table} {$str} {$where}";
		}
		if ($type == 'count') {
			$where = $this->_build_where();
			$field_list = explode(',', $this->field);//为了不影响后面结果，此处用局部变量
			$field = count($field_list) > 1 ? '*' : $this->field; 
			$sql = "select count({$field}) from {$this->table} {$where}";
		}
		return $sql;
	}
	//返回一条记录
	public function item(){
		$sql = $this->_build_sql('select').' limit 1';
		$stmt = $this->pdo->prepare($sql);
		$stmt->execute();
		$res = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return isset($res[0]) ? $res[0] : false;
	}
	//返回多条数据记录
	public function lists(){
		$sql = $this->_build_sql('select');
		$stmt = $this->pdo->prepare($sql);
		$stmt->execute();
		$res = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $res;
	}
	//添加数据
	public function insert($data){
		$sql = $this->_build_sql('insert',$data);
		$stmt = $this->pdo->prepare($sql);
		$stmt->execute();
		return $this->pdo->lastInsertId();
	}
	//删除数据
	public function delete(){
		$sql = $this->_build_sql('delete');
		$stmt = $this->pdo->prepare($sql);
		$stmt->execute();
		return $stmt->rowCount();//返回受影响行数
	}
	//更新数据
	public function update($data){
		$sql = $this->_build_sql('update', $data);
		$stmt = $this->pdo->prepare($sql);
		$stmt->execute();
		return $stmt->rowCount();//返回受影响行数
	}
	//查询数据总数
	public function count(){
		$sql = $this->_build_sql('count');
		$stmt = $this->pdo->prepare($sql);
		$stmt->execute();
		$total = $stmt->fetchColumn(0);
		// exit(var_dump($total));
		return $total;
	}
	//生成分页html(bootstrap分页)
	private function _subPages($cur_page, $pageSize, $total, $path){

		$symbol = '?';
		$index = strpos($path, '?');
		if ($index !== false && $index > 0) {//返回字符在字符串的位置（判断是否有？）
			$symbol = '&';
		}
		//每次最多展示多少页
		//当前页数（当前是第几页）$cur_page
		//数据总数$total
		//每页大小$pageSize
		$page_count = ceil($total/$pageSize);//页数
		$html = '';

		if ($cur_page > 1) {
			//生成首页
			$html .= "<li><a href='{$path}{$symbol}page=1'>首页</a></li>";
			//生成上一页
			$pre_page = $cur_page - 1;//上一页		
			$html .= "<li><a href='{$path}{$symbol}page={$pre_page}'>上一页</a></li>";
		}
		
		//生成数字页部分
		$start = $cur_page > ($page_count - 6) ? ($page_count - 6) : $cur_page;
		$start = $start - 2;
		$start = ($start <= 0) ? 1 : $start;
		$end = ($cur_page + 6) > $page_count ? $page_count : ($cur_page + 6);
		// $end = $end - 2;
		// if ($cur_page + 2 >= $end && $page_count >= 6) {
		// 	$start = $start + 2;
		// 	$end = $end + 2;
		// }

		for($i = $start;$i <= $end;$i++){
			$html .= $i == $cur_page ? "<li class='active'><a>{$i}</a></li>" : "<li><a href='{$path}{$symbol}page={$i}'>{$i}</a></li>";
		}

		if ($cur_page < $page_count) {
			//生成下一页
			$after_page = $cur_page + 1;
			$html .= "<li><a href='{$path}{$symbol}page={$after_page}'>下一页</a></li>";
			//生成尾页
			$html .= "<li><a href='{$path}{$symbol}page={$page_count}'>尾页</a></li>";
		}
		
		$html = '<nav aria-label="Page navigation"><ul class="pagination">'.$html.'</ul></nav>';

		return $html;
	}
	//分页
	public function pages($page, $pageSize = 3, $path = '/'){
		$count = $this->count();
		$this->limit = ($page - 1) * $pageSize.','.$pageSize;
		$data = $this->lists();
		// echo '<pre>';
		// exit(var_dump($data));
		$pages = $this->_subPages($page, $pageSize, $count, $path);
		return array('total'=>$count,'data'=>$data, 'pages'=>$pages);
	}
}