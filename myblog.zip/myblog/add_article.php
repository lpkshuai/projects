<?php  
//判断用户是否登录
session_start();
$user = isset($_SESSION['user']) ? $_SESSION['user'] : false;
if (!$user) {
	exit('您还未登录，请先登录后再发表博客！');
}
// 引入
require_once $_SERVER['DOCUMENT_ROOT'].'/lib/Db.php';

$db = new Db();
$cates = $db->table('cates')->lists();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>发表博客</title>
	<link rel="stylesheet" href="static/plugins/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="static/css/add_article.css">
	<script src="static/plugins/jquery/jquery-3.3.1.min.js"></script>
	<script src="static/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="static/plugins/wangEditor/release/wangEditor.min.js"></script>
	<script src="static/js/ui.js"></script>
</head>
<body>
	<div class="form">
		<div class="input-group input-group-sm">
			<span class="input-group-addon">博客标题</span>
			<input type="text" class="form-control" name="title" id="title" placeholder="请输入博客标题">
		</div>
		<div class="input-group input-group-sm">
			<span class="input-group-addon">博客分类</span>
			<select name="type" id="type" class="form-control">
				<?php foreach ($cates as $cate) { ?>	
				<option value="<?php echo $cate['id']; ?>"><?php echo $cate['title']; ?></option>
				<?php } ?>
			</select>
		</div>
		<div class="input-group input-group-sm">
			<span class="input-group-addon">&#12288;关键字</span>
			<input type="text" class="form-control" name="keywords" id="keywords" placeholder="请输入博客关键字">
		</div>
		<div class="input-group input-group-sm">
			<span class="input-group-addon">&#12288;&#12288;描述</span>
			<input type="text" class="form-control" name="desc" id="desc" placeholder="请输入博客描述">
		</div>
		<div class="input-group input-group-sm">
			<span class="input-group-addon">博客内容</span>
			<!-- 引入编辑器 -->
			<div id="editor"></div>
		</div>
		<button class="btn btn-success form-control" onclick="submit();">提交</button>
	</div>
</body>
<script>
	//初始化编辑器
	var editor;
	function initEditor() {
		//文本编辑器调用
		var E = window.wangEditor;
		editor = new E('#editor');
		//或者 var editor = new E(document.getElementById('editor'));
		//配置编辑区域z-index
		editor.customConfig.zIndex = 100;
		//开启上传图片功能
		editor.customConfig.uploadImgServer = '/upload.php';
		//配置上传图片的参数
		editor.customConfig.uploadFileName = 'file_image';
		//提示配置
		editor.customConfig.customAlert = function (info) {
			//info是需要定义的内容
			UI.alert({msg:info, icon:'error'});
		};
		editor.create();
	}
	initEditor();
	//提交博客
	function submit() {
		var data = {};
		data.title = $.trim($('input[name = "title"]').val());
		data.cid = $.trim($('select[name = "type"]').val());
		data.keywords = $.trim($('input[name = "keywords"]').val());
		data.desc = $.trim($('input[name = "desc"]').val());
		//获取编辑器内容(官网文档有介绍获取方法)
		data.contents = editor.txt.html();
		// alert(contents);
		if (data.title == '') {
			UI.alert({msg:'请输入博客标题', icon:'warn'});
			return;
		}
		if (data.contents == '<p><br></p>') {
			UI.alert({msg:'博客内容不能为空', icon:'warn'});
			return;
		}
		$.post('/service/submit_article.php', data, function(res) {
			if (res.code > 0) {
				UI.alert({msg:res.msg, icon:'error'});
			}else {
				UI.alert({msg:res.msg, icon:'ok'});
				setTimeout(function () {
					parent.window.location.reload();
				}, 1000);
			}
		}, 'json');
	}
</script>
</html>