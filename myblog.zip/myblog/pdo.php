<?php
//访问mysql数据库
$dsn = 'mysql:host=127.0.0.1;dbname=myblog';
$username = 'root';
$pwd = 'lpk19961224';
$pdo = new PDO($dsn, $username, $pwd);

$sql = 'select * from cates where id=:id';
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':id', 5);
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo '<pre>';
print_r($rows);
echo '</pre>';