﻿# Host: localhost  (Version: 5.5.53)
# Date: 2019-04-25 13:50:59
# Generator: MySQL-Front 5.3  (Build 4.234)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "article"
#

CREATE TABLE `article` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `cid` int(10) NOT NULL DEFAULT '0' COMMENT '文章分类id',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '文章标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '文章关键字',
  `desc` varchar(255) NOT NULL DEFAULT '' COMMENT '文章描述',
  `contents` text NOT NULL,
  `pv` int(10) NOT NULL DEFAULT '0' COMMENT '文章阅读量',
  `add_time` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `index_cid` (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

#
# Data for table "article"
#

INSERT INTO `article` VALUES (1,1,1,'广济桥受损','PHP','123','据广州日报消息，记者从潮州市方面获悉，今日凌晨（20日）4时左右，一艘梅州大埔的采沙船沿韩江顺流漂下，撞到国家级文物保护单位——潮州广济桥。',2,0),(2,2,2,'第二次测试','HTML','456','手机“来电显示”是一种基础的通讯服务功能，智能手机还会显示特殊的“标注”信息，比如有的号码被标注为“广告”“骚扰”，甚至是“诈骗电话”，这在一定程度上方便了用户是否选择接听。然而随着电话标注功能被广泛使用，这个功能近来开始慢慢“变味”了。',5,0),(3,3,2,'第三次测试','css','789','去年年底，意大利的两名学生因烧烤引发山火，被控放火焚烧森林。近日，法院宣布了对他们的处罚，这两名学生共需支付2700万欧元(约2亿人民币)的罚款。',8,0),(5,2,2,'添加数据功能测试','','','',8,0),(6,4,4,'测试','','','',0,0),(7,5,5,'测试','','','',0,0),(8,6,6,'测试','','','',0,0),(9,7,2,'测试','','','',0,0),(10,8,2,'测试','','','',0,0),(11,9,9,'测试','','','',0,0),(12,1,10,'最新发表测试','测试','对发表功能测试','&lt;p&gt;测试博客能否正常保存文章到数据库。&lt;/p&gt;',0,1556094058),(13,1,10,'最新发表测试','测试','对发表功能测试','&lt;p&gt;测试博客能否正常保存文章到数据库。&lt;/p&gt;',0,1556094284),(14,1,10,'test2','','','&lt;p&gt;test2&lt;/p&gt;',0,1556094335),(15,1,1,'test3','','','&lt;p&gt;123456&lt;/p&gt;',0,1556094429),(16,1,10,'最后一次测试','测试','这确实是最后一次了','&lt;p&gt;这次一定没问题！！！&lt;/p&gt;',0,1556095066),(17,1,10,'跳转测试','测试','','&lt;p&gt;这是提交成功后跳转的测试。&lt;/p&gt;',0,1556097965),(18,1,1,'PHP学习之插入排序的实现','插入排序','','&lt;p&gt;&lt;strong&gt;插入排序基本思路&lt;/strong&gt;：将数组分为两个区(已排序区和未排序区)，假定数组的第一个元素处于已排序区， 第一个元素之后的所有元素都处于未排序部分。排序时用到双层循环，外层循环用于从未排序部分中取出待排序元素，并逐步缩小未排序部分，内层循环用于从已排序部分寻找插入位置（即不断地从已排序部分寻找比待排序元素大的元素）， 然后将较大的已排序区的元素后移，后移的最终结果是已排序区元素的最后一个元素占据待排序元素原来的位置，而已排序区中间空出一个位置），最后将待排序元素插入元素后移之后留下的空位。&amp;nbsp;&lt;/p&gt;&lt;p&gt;&lt;code&gt;//插入排序&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;function&lt;/code&gt; &lt;code&gt;insert_sort(&lt;/code&gt;&lt;code&gt;$arr&lt;/code&gt;&lt;code&gt;) {&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/code&gt;&lt;code&gt;//获取数组单元个数&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/code&gt;&lt;code&gt;$count&lt;/code&gt; &lt;code&gt;= &lt;/code&gt;&lt;code&gt;count&lt;/code&gt;&lt;code&gt;(&lt;/code&gt;&lt;code&gt;$arr&lt;/code&gt;&lt;code&gt;);&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/code&gt;&lt;code&gt;//外层循环用于从未排序区域中取出待排序元素&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/code&gt;&lt;code&gt;for&lt;/code&gt; &lt;code&gt;(&lt;/code&gt;&lt;code&gt;$i&lt;/code&gt;&lt;code&gt;=1; &lt;/code&gt;&lt;code&gt;$i&lt;/code&gt; &lt;code&gt;&amp;lt; &lt;/code&gt;&lt;code&gt;$count&lt;/code&gt;&lt;code&gt;; &lt;/code&gt;&lt;code&gt;$i&lt;/code&gt;&lt;code&gt;++) {&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/code&gt;&lt;code&gt;//获取当前需要插入已排序区域的元素值&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/code&gt;&lt;code&gt;$temp&lt;/code&gt; &lt;code&gt;= &lt;/code&gt;&lt;code&gt;$arr&lt;/code&gt;&lt;code&gt;[&lt;/code&gt;&lt;code&gt;$i&lt;/code&gt;&lt;code&gt;];&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/code&gt;&lt;code&gt;//内层循环用于从已排序区域寻找待排序元素的插入位置&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/code&gt;&lt;code&gt;for&lt;/code&gt; &lt;code&gt;(&lt;/code&gt;&lt;code&gt;$j&lt;/code&gt;&lt;code&gt;=&lt;/code&gt;&lt;code&gt;$i&lt;/code&gt;&lt;code&gt;-1; &lt;/code&gt;&lt;code&gt;$j&lt;/code&gt; &lt;code&gt;&amp;gt;= 0; &lt;/code&gt;&lt;code&gt;$j&lt;/code&gt;&lt;code&gt;--) {&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/code&gt;&lt;code&gt;//如果$arr[$i]比已排序区域的$arr[$j]小，就后移$arr[$j]&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/code&gt;&lt;code&gt;if&lt;/code&gt; &lt;code&gt;(&lt;/code&gt;&lt;code&gt;$temp&lt;/code&gt; &lt;code&gt;&amp;lt; &lt;/code&gt;&lt;code&gt;$arr&lt;/code&gt;&lt;code&gt;[&lt;/code&gt;&lt;code&gt;$j&lt;/code&gt;&lt;code&gt;]) {&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; &lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/code&gt;&lt;code&gt;$arr&lt;/code&gt;&lt;code&gt;[&lt;/code&gt;&lt;code&gt;$j&lt;/code&gt;&lt;code&gt;+1] = &lt;/code&gt;&lt;code&gt;$arr&lt;/code&gt;&lt;code&gt;[&lt;/code&gt;&lt;code&gt;$j&lt;/code&gt;&lt;code&gt;];&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/code&gt;&lt;code&gt;$arr&lt;/code&gt;&lt;code&gt;[&lt;/code&gt;&lt;code&gt;$j&lt;/code&gt;&lt;code&gt;] = &lt;/code&gt;&lt;code&gt;$temp&lt;/code&gt;&lt;code&gt;;&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/code&gt;&lt;code&gt;} &lt;/code&gt;&lt;code&gt;else&lt;/code&gt; &lt;code&gt;{&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/code&gt;&lt;code&gt;//如果$arr[$i]不小于$arr[$j]，则对已排序区无需再排序&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/code&gt;&lt;code&gt;break&lt;/code&gt;&lt;code&gt;;&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/code&gt;&lt;code&gt;}&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/code&gt;&lt;code&gt;}&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/code&gt;&lt;code&gt;}&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/code&gt;&lt;code&gt;return&lt;/code&gt; &lt;code&gt;$arr&lt;/code&gt;&lt;code&gt;;&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;}&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;p&gt;&lt;code&gt;$arr&lt;/code&gt; &lt;code&gt;= &lt;/code&gt;&lt;code&gt;array&lt;/code&gt;&lt;code&gt;(6, 19, 26, 62, 88, 99, 18, 16, 1);&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;code&gt;var_dump(insert_sort(&lt;/code&gt;&lt;code&gt;$arr&lt;/code&gt;&lt;code&gt;));&lt;/code&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=\"background-color: rgb(241, 241, 241); color: rgb(199, 37, 78); font-family: Menlo, Monaco, Consolas, &amp;quot;Courier New&amp;quot;, monospace; font-size: 12.6px;\"&gt;　　测试结果：&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;img src=\"/images/1.png\" style=\"max-width: 100%;\"&gt;&amp;nbsp;&lt;br&gt;&lt;/p&gt;',0,1556113011);

#
# Structure for table "article_contents"
#

CREATE TABLE `article_contents` (
  `aid` int(10) NOT NULL AUTO_INCREMENT COMMENT '文章id',
  `contents` text NOT NULL COMMENT '文章内容',
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "article_contents"
#


#
# Structure for table "cates"
#

CREATE TABLE `cates` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

#
# Data for table "cates"
#

INSERT INTO `cates` VALUES (1,'编程语言'),(2,'软件设计'),(3,'web前端'),(4,'企业信息化'),(5,'安卓开发'),(6,'iOS开发'),(7,'软件工程'),(8,'数据库技术'),(9,'操作系统'),(10,'其他分类');

#
# Structure for table "comments"
#

CREATE TABLE `comments` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '上一级评论',
  `aid` int(10) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  `msg` varchar(255) NOT NULL DEFAULT '',
  `add_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='评论';

#
# Data for table "comments"
#


#
# Structure for table "user"
#

CREATE TABLE `user` (
  `uid` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# Data for table "user"
#

INSERT INTO `user` VALUES (1,'lpk','123');
