<?php 
// 引入
require_once $_SERVER['DOCUMENT_ROOT'].'/lib/Db.php';

$db = new Db();
//查询数据
// $res = $db->table('article')->where(array('id'=>2))->item();
// $res = $db->table('article')->field('id, title,  pv')->order('id desc')->where('id>0')->limit(2)->lists();
//插入数据
// $data = array('uid'=>2,'cid'=>3,'title'=>'添加数据功能测试','pv'=>8);
//$id = $db->table('article')->insert($data);
//删除数据
//$res = $db->table('article')->where(array('id'=>4))->delete();
//更新数据
// $data = array('title'=>'广济桥受损');
// $res = $db->table('article')->where(array('id'=>1))->update($data);

// echo '<pre>';
// print_r($res);

//分页查询
$cid = $_GET['cid'];//分类id
$page = $_GET['page'];//第几页
$pageSize = 2;//每页加载数据条数

$res = $db->table('article')->field('id,title')->where('cid='.$cid)->pages($page, $pageSize,'/test.php?cid='.$cid);//->setPage(array('page'=>$page,'pageSize'=>$pageSize))
// echo '<pre>';
// print_r($res);
// echo json_encode($res);
?>
<!DOCTYPE html>
<html>
<head>
	<title>分页</title>
	<link rel="stylesheet" href="static/plugins/bootstrap/css/bootstrap.min.css">
</head>
<body>
	<div class="container" style="margin-top: 50px;">
		<p>共查询出<?php echo $res['total']; ?>条数据</p>
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>ID</th>
					<th>标题</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($res['data'] as $article){ ?>
				<tr>
					<td><?php echo $article['id']; ?></td>
					<td><?php echo $article['title']; ?></td>
				</tr>
				<?php } ?>
			</tbody>
		</table>
		<div>
			<?php echo $res['pages']; ?>
		</div>
		
	</div>
</body>
</html>