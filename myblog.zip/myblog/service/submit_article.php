<?php  
session_start();
$user = isset($_SESSION['user']) ? $_SESSION['user'] : false;
if (!$user) {
	exit(json_encode(array('code'=>1, 'msg'=>'请先登录！')));
}
//提交的博客
$data['uid'] = $user['uid'];
$data['title'] = trim($_POST['title']);
$data['cid'] = (int)trim($_POST['cid']);
$data['keywords'] = trim($_POST['keywords']);
$data['desc'] = trim($_POST['desc']);
$data['contents'] = htmlspecialchars(trim($_POST['contents']),true);
$data['add_time'] = time();
// echo '<pre>';
// print_r($title);
if (!$data['title']) {
	exit(json_encode(array('code'=>1, 'msg'=>'博客标题不能为空')));
}
//判断博客内容是否输入


// 引入
require_once $_SERVER['DOCUMENT_ROOT'].'/lib/Db.php';

$db = new Db();

//保存数据到数据库
$id = $db->table('article')->insert($data);
if (!$id) {
	exit(json_encode(array('code'=>1, 'msg'=>'保存失败！')));
}
exit(json_encode(array('code'=>0, 'msg'=>'保存成功！')));