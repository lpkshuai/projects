<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>登录</title>
	<link rel="stylesheet" href="static/plugins/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="static/css/login.css">
	<script src="static/plugins/jquery/jquery-3.3.1.min.js"></script>
	<script src="static/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="static/js/ui.js"></script>
</head>
<body>
	<div class="title">登录博客</div>
	<div class="form">
		<div class="input-group input-group-sm">
			<span class="input-group-addon">用户名</span>
			<input type="text" class="form-control" name="username" placeholder="请输入用户名">
		</div>
		<div class="input-group input-group-sm">
			<span class="input-group-addon">密&#12288;码</span>
			<input type="password" class="form-control" name="pwd" placeholder="请输入密码">
		</div>
	</div>
	<button class="btn btn-primary btn-sm btn-block" onclick="login();">登录</button>
</body>
<script>
	function login () {
		var username = $.trim($('input[name="username"]').val());
		var pwd = $.trim($('input[name="pwd"]').val());
		if (username == '') {
			// alert("用户名不能为空！");
			UI.alert({msg:'用户名不能为空！',icon:'error'});
			return;
		}
		if (pwd == '') {
			// alert("密码不能为空！");
			UI.alert({msg:'密码不能为空！',icon:'error'});
			return;
		}
		// 提交验证
		$.post('/service/dologin.php', {username: username,pwd: pwd}, function(res) {
			if (res.code > 0) {
				UI.alert({msg:res.msg,icon:'error'});
			}else {
				UI.alert({msg:res.msg,icon:'ok'});
				setTimeout(function () {
					parent.window.location.reload();
				},1000);
			}
		},'json');
	}
</script>
</html>